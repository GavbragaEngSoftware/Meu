const apiKey = '9d5fdfe234f2e475868da6c355b4696b'; // Insira sua chave da API TMDB
const baseImageUrl = 'https://image.tmdb.org/t/p/w500';
const carouselIndicators = document.getElementById('carouselIndicators');
const carouselContent = document.getElementById('carouselContent');
const newSeriesCards = document.getElementById('newSeriesCards');
const authorDetails = document.getElementById('authorDetails');
const favoriteSeriesCards = document.getElementById('favoriteSeriesCards');

// Função para carregar séries populares
async function loadPopularSeries() {
  try {
    const response = await fetch(`https://api.themoviedb.org/3/tv/popular?9d5fdfe234f2e475868da6c355b4696b&language=pt-BR&page=1`);
    const data = await response.json();

    if (data.results) {
      data.results.forEach((serie, index) => {
        // Criar indicador do carrossel
        const indicator = document.createElement('button');
        indicator.type = 'button';
        indicator.dataset.bsTarget = '#carouselPopular';
        indicator.dataset.bsSlideTo = index;
        indicator.ariaLabel = `Slide ${index + 1}`;
        if (index === 0) indicator.classList.add('active');
        carouselIndicators.appendChild(indicator);

        // Criar slide do carrossel
        const slide = document.createElement('div');
        slide.className = `carousel-item${index === 0 ? ' active' : ''}`;
        slide.innerHTML = `
          <img src="${baseImageUrl}${serie.poster_path}" class="d-block w-100" alt="${serie.name}">
          <div class="carousel-caption d-none d-md-block">
            <h5>${serie.name}</h5>
            <p>${serie.overview.substring(0, 100)}...</p>
          </div>
        `;
        slide.addEventListener('click', () => {
          window.location.href = `detalhes.html?id=${serie.id}`;
        });
        carouselContent.appendChild(slide);
      });
    }
  } catch (error) {
    console.error('Erro ao carregar séries populares:', error);
  }
}

// Função para carregar novas séries
async function loadNewSeries() {
  try {
    const response = await fetch(`https://api.themoviedb.org/3/tv/airing_today?api_key=${apiKey}&language=pt-BR&page=1`);
    const data = await response.json();

    if (data.results) {
      data.results.forEach((serie) => {
        const card = document.createElement('div');
        card.className = 'col-md-4 mb-4';
        card.innerHTML = `
          <div class="card h-100">
            <img src="${baseImageUrl}${serie.poster_path}" class="card-img-top" alt="${serie.name}">
            <div class="card-body">
              <h5 class="card-title">${serie.name}</h5>
              <p class="card-text">${serie.overview.substring(0, 100)}...</p>
              <button class="btn btn-primary" onclick="goToDetails(${serie.id})">Ver detalhes</button>
            </div>
          </div>
        `;
        newSeriesCards.appendChild(card);
      });
    }
  } catch (error) {
    console.error('Erro ao carregar novas séries:', error);
  }
}

// Função para carregar informações do autor
async function loadAuthorInfo() {
  try {
    // Substitua esta URL pelo endpoint real do JSONServer se necessário
    const response = await fetch('http://localhost:3000/profile');
    const data = await response.json();

    if (data) {
      authorDetails.innerHTML = `
        <img src="${data.poster_path}" alt="Avatar do autor" class="rounded-circle me-3" width="100">
        <div>
          <h4>${data.name}</h4>
          <p>${data.bio}</p>
          <p><strong>Curso:</strong> ${data.course}</p>
          <p><strong>Email:</strong> <a href="mailto:${data.email}">${data.email}</a></p>
          <div>
            <a href="${data.facebook}" target="_blank" class="btn btn-primary btn-sm me-2">Facebook</a>
            <a href="${data.twitter}" target="_blank" class="btn btn-info btn-sm me-2">Twitter</a>
            <a href="${data.instagram}" target="_blank" class="btn btn-danger btn-sm">Instagram</a>
          </div>
        </div>
      `;
    }
  } catch (error) {
    console.error('Erro ao carregar informações do autor:', error);
  }
}

// Função para carregar séries favoritas
async function loadFavoriteSeries() {
  try {
    const response = await fetch(`https://api.themoviedb.org/3/account/{account_id}/favorite/tv?api_key=${apiKey}&language=pt-BR&page=1`);
    const data = await response.json();

    if (data.results) {
      data.results.forEach((serie) => {
        const card = document.createElement('div');
        card.className = 'col-md-4 mb-4';
        card.innerHTML = `
          <div class="card h-100">
            <img src="${baseImageUrl}${serie.poster_path}" class="card-img-top" alt="${serie.name}">
            <div class="card-body">
              <h5 class="card-title">${serie.name}</h5>
              <p class="card-text">${serie.overview.substring(0, 100)}...</p>
              <button class="btn btn-primary" onclick="goToDetails(${serie.id})">Ver detalhes</button>
            </div>
          </div>
        `;
        favoriteSeriesCards.appendChild(card);
      });
    } else {
      favoriteSeriesCards.innerHTML = '<p>Você ainda não tem séries favoritas.</p>';
    }
  } catch (error) {
    console.error('Erro ao carregar séries favoritas:', error);
  }
}

// Inicializar todas as funções
loadPopularSeries();
loadNewSeries();
loadAuthorInfo();
loadFavoriteSeries();
